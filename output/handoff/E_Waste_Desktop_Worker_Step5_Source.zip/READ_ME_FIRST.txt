E-Waste Grid - Step 5 source desktop preview

This bundle contains reviewed source and the trusted offline release manifest.
It contains no private settings, credentials, virtual environment, coordinator,
installer or automatic startup. Python 3.12 with Tkinter remains a prerequisite.
Docker Desktop must be running in Linux-container mode on a supported amd64 PC.
Do not build workload images on this laptop: copy the separate images.tar file.

Extract this ZIP into a new directory. In PowerShell in that directory, run:
  py -3.12 -m venv .venv
  .\.venv\Scripts\python.exe -m pip install -r worker\requirements.txt
  .\.venv\Scripts\python.exe worker\desktop.py
Dependency setup may need the internet once. The image import itself is offline.

In the app:
1. Enter the coordinator's API URL. localhost points to THIS laptop; use the
   coordinator's actual LAN IP and port. Select trusted-demo HTTP only for LAN.
2. Choose owner-approved CPU/RAM ceilings. Normal image jobs need 2 GiB RAM.
3. Click Import offline workloads and select the team's images.tar.
4. Wait for archive verification, import and real Docker preflight. Cancellation
   never starts a worker; Docker may retain content already imported.
5. Click Prepare connection; share only the pairing code with the grid admin.
6. Inspect and approve the invitation on this laptop to start computing.
7. Pause/Resume/Stop remain owner controls. Closing waits for owned work to stop.

Keep the trusted current.json from this reviewed source bundle. Replacing the
archive AND manifest removes the trust check; checksums alone are not publisher
authentication. Use the checksum supplied by the team through a trusted channel.
Check SHA-256 with Get-FileHash before opening a replacement source ZIP.

Record OS/Docker version, import result, node ID and a ten-photo job with two
accepted tasks and exact downloaded results. Never share pairing/node secrets,
protected per-user state, admin tokens or full unreviewed logs. Installer/reboot
and multi-device fault testing are later milestones. No cloud deployment here.
