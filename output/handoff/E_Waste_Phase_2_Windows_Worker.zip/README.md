# Windows worker handoff

This contains the approved worker source and pinned model, not the API/dashboard or Git history. Extract into a new directory. Install/create a fresh Python 3.12 .venv-local there; never copy the API host credentials/environment. Follow docs/PHASE_2_WINDOWS_WORKER.md. Start Docker Desktop in Linux mode, build the two approved workload images, and use the current server URL/enrollment token. Setup instructions are for a private development demo.
